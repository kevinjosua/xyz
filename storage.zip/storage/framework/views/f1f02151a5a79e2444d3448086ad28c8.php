

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col">
                <h3>Rekap Data Pengiriman</h3>
            </div>
        </div>
        <div class="card p-5">
            <table id="example" class="display nowrap table table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kurir</th>
                        <th>Tujuan</th>
                        <th>Tanggal</th>
                        <th>Waktu</th>
                        <th>Armada</th>
                        <th>Nomor Kendaraan</th>
                        <th>Muatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($data->kurir->nama_kurir ?? '-'); ?></td>
                            <td><?php echo e($data->tujuan); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($data->tanggal)->translatedFormat('d F Y')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($data->waktu)->format('h:i A')); ?></td>
                            <td><?php echo e($data->armada); ?></td>
                            <td><?php echo e($data->nomor_kendaraan); ?></td>
                            <td><?php echo e($data->muatan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css">
    <script>
        new DataTable('#example', {
            // autoFill: true
            scrollX: true

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\xyz\resources\views/admin/pengiriman/index.blade.php ENDPATH**/ ?>